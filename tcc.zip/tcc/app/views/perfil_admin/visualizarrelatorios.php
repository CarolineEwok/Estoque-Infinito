<?php require_once "indexperfil.php";?>

<div id="page-wrapper" >
    <div id="page-inner" class="container">


    <div class="row">


    <div class="col-md-6 col-sm-12 col-xs-12" style="margin-left: 135px; margin-top: 50px" aria-hidden="true" >
        <div class="panel panel-default">
            <div class="panel-heading">
                Relatórios
            </div>
            <div class="panel-body">
                <div id="morris-bar-chart"></div>
            </div>
        </div>
    </div>


</div>
    </div>
</div>
<!-- /. PAGE INNER  -->
</div>
<!-- /. PAGE WRAPPER  -->
</div>
</div>


<?php require_once "rodape.php"; ?>