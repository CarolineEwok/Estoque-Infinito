<?php require_once "indexperfil.php"; ?>


<div id="page-wrapper" >
    <div id="page-inner" class="container">


    </div>









</div>
<!-- /. PAGE WRAPPER  -->
</div>


<script src="../../../assets/js/jquery-1.10.2.js"></script>
<!-- BOOTSTRAP SCRIPTS -->
<script src="../../../assets/js/bootstrap.min.js"></script>
<!-- METISMENU SCRIPTS -->
<script src="../../../assets/js/jquery.metisMenu.js"></script>
<!-- MORRIS CHART SCRIPTS -->
<script src="../../../assets/js/morris/raphael-2.1.0.min.js"></script>
<script src="../../../assets/js/morris/morris.js"></script>
<!-- CUSTOM SCRIPTS -->
<script src="../../../assets/js/custom.js"></script>




</body>
</html>

