<?php

function listarVends(){
    $crud = new CrudVendedor();
    $listaAdmins = $crud->getVendedores();
    require '../views/perfil_vendedor/visualizarpedidos.php';
}

function cadastrarVend(){
    $crud = new CrudVendedor();
    include 'http://localhost/tcc/app/views/cadastro_vend.html';
}

function salvarVend(){ //DANDO ERRO
    echo "<pre>";

    $usuario = new Vendedor($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['telefone'], $_POST['cpf'],$_POST['empresa']);
        $vend = new CrudVendedor();
    $resultado = $vend->cadastrar($usuario);

    header("Location: vend_controller.php");
}

function editarVend(){
    $crud = new CrudVendedor();

    $vend = $crud->getVendedor(4,5);

    //require_once "../views/perfil_vendedor/editar_vendedor.php";
}

function excluirVend($id){
    $crud = new CrudVendedor();
    $crud->excluir($id);
    require 'http://localhost/tcc/app/controllers/produto_controller.php?acao=listar';
}

//ROTAS
if (isset($_GET['acao']) && !empty($_GET['acao']) ) {

    if ($_GET['acao'] == 'cadastrar') {
        //echo "chegou na rota";
        cadastrarVend();

    } elseif ($_GET['acao'] == 'salvar') {
        salvarVend();

    } elseif ($_GET['acao'] == 'editarAdmin') {
        editarVend();

    }elseif ($_GET['acao'] == 'excluir') {
        excluirVend($_GET['id']);

    }else {
        require 'http://localhost/tcc/app/views/cadastro_admin.php';
    }
} else {
    require 'http://localhost/tcc/app/views/cadastro_admin.php';
}